# -*- coding: utf-8 -*-
"""
URPP Evolution in Action tutorial:
Python - basics

Date: March 2015
@author: hlischer
"""

# Solutions exercise 1: ###################
# a) calculate the sum of 1+2+...+300
sum = 0
for number in range(1, 301):
    sum += number
print sum

# b) calculate 1 + 1/1! + 1/2! + ... + 1/10!
sum = 1
for number in range(1, 11):
    factorial = 1
    for count in range(2, number+1):
        factorial *= count
    sum += 1/float(factorial)
    print sum

# c) numbers from 1 to 100 and divisible by 2 and 3
for number in range(1, 101):
    if number%2 == 0 and number%3 == 0:
        print number
    

# Solutions exercise 2: ###################
# a) how many terms until the sum exceeds one million?
target = 1000000
sum = 0
count = 0
while sum <= target:
    count += 1
    sum += count
print count


# Solutions exercise 3: ###################
data = [['A1', 28], ['B1', 99], ['D3', 55], ['B2', 27], ['B4', 25], ['B5', 9], 
        ['C3', 36], ['A7', 30], ['B6', 38], ['A3', 1], ['B3', 36], ['B7', 21], 
        ['C1', 122], ['A4', 0], ['C2', 87], ['A6', 22], ['C4', 3], ['D1', 0], 
        ['A2', 32], ['D2', 5], ['A8', 19], ['B8', 12], ['D4', 62], ['D5', 98], 
        ['A5', 10], ['D6', 32]]

# a)	Number of sites
print 'Nb of sites: ', len(data)

# b)	Number of birds at the 7th site
print 'Nb of birds at 7th site: ', data[6][1]

# c)	Number of birds at second last site
print 'Nb of birds at second last site: ', data[-2][1]

# d)	Total number of birds counted across all sites
sum = 0
for site in data:
    sum += site[1]
print 'Total nb of birds: ', sum

# e)	Average number of birds seen at sites?
print 'Average nb of birds: ', float(sum)/len(data)

# f)	Total number of birds counted at sites with codes beginning with C
sum = 0
for site in data:
    if(site[0].startswith('C')):
        sum += site[1]
print 'Total nb of birds at sites with C: ', sum

# g) sort list
data.sort()
print data

# h) correct entry
for site in data:
    if(site[0] == 'B1'):
        site[1] = 145
        break
print data

# i) add entries
data.append(['E1', 34])
data.append(['E2', 26])
data.append(['E3', 68])

index = 0
for site in data:
    if(site[0] == 'C4'):
        index = data.index(site) + 1   # +1 as we want to add it after site C4
        break
data.insert(index, ['C5', 11])
print data
    
    
# Solutions exercise 4: ###################
# a) average line length
reader = open('simple.fa', 'r')
line = reader.readline().rstrip('\r\n')
total = 0
count = 0
while line != '':
    count += 1
    total += len(line)
    line = reader.readline().rstrip('\r\n')
reader.close()
print 'Average line length: ', float(total) / float(count)

# b) average seq. length    
reader = open('simple.fa', 'r')
line = reader.readline().rstrip('\r\n')
total = 0
count = 0
while line != '':
    if not(line.startswith('>')):
        count += 1
        total += len(line)
    line = reader.readline().rstrip('\r\n')
reader.close()
print 'Average seq length: ', float(total) / float(count)
  
# c) rename seq and safe into a new file
reader = open('simple.fa', 'r')
writer = open('simple_mod.fa', 'w')
line = reader.readline().rstrip('\r\n')
count = 1
while line != '':
    if line.startswith('>'):
        print >> writer, '>read_', count
        count += 1
    else:
        print >> writer, line
    line = reader.readline().rstrip('\r\n')
reader.close()
writer.close()

# d) file into list
data = list()
seqName = ''
reader = open('simple.fa', 'r')
line = reader.readline().rstrip('\r\n')
while line != '':
    if line.startswith('>'):
        seqName = line
    else:
        data.append([seqName, line])
        seqName = ''
    line = reader.readline().rstrip('\r\n')
reader.close()

# go backwards through list and remove seq < 60bp
indexes = range(len(data))
indexes.reverse()

for index in indexes:
    dataItem = data[index]
    if len(dataItem[1]) < 60:
        del data[index]

#print new files
writerNames = open('simple_Names.fa', 'w')
writerSeqLength = open('simple_SeqLength.fa', 'w')
for dataItem in data:
    print >> writerNames, dataItem[0]
    print >> writerSeqLength, len(dataItem[1])
writerNames.close()
writerSeqLength.close()
    

    