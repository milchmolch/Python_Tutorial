# -*- coding: utf-8 -*-
"""
URPP Evolution in Action tutorial:
Python - basics part2

Date: April 2015
@author: hlischer
"""

# Solutions exercise 1: ###################
from Bio.Seq import Seq
from Bio.Alphabet import IUPAC
seq1 = Seq("CTTTGCTCGTCTGATGCGCATTATTCCGCACTCGCTTGCGGCGGCAATGCTTtGGCGGGATTTTATTACGCTTTGGATTACAGGCGTTTGCCAGTCTGGAC", IUPAC.ambiguous_dna)
seq2 = Seq("GCTGAAAGGCGCATGGGCGGCGCGTACCATCCaGATGAAAGCTCAGGTGAAGCGTCAGGAAgAGGTGGCGAAAGCCATCTACGACCGCGGGATGAACAGCATTGAGCGGGCG", IUPAC.ambiguous_dna)
seq3 = Seq("ATCATAGCCTGCAAGTGGCCGGAGAGCGAAGGGcTATCCGGCCAGGGTGAAATTATCGCCGCGAACGCACAATTTGATATCGACGaGTAAAGTACTCAAACGGCGCGCTCCACACATGCAC", IUPAC.ambiguous_dna)

# a) subsequence
subSeq1 = seq1[8:30]  #remember: 0-based and end not included
subSeq1

# b) concatenate and upper case
concatSeq = seq1 + seq2 + seq3
concatSeqUpper = concatSeq.upper()
concatSeqUpper
 
# c) GC content
100 * float(concatSeqUpper.count("G") + concatSeqUpper.count("C")) / len(concatSeqUpper)

#or with the GC function of the SeqUtils module:
from Bio.SeqUtils import GC
GC(concatSeqUpper)  


# Solutions exercise 2: ###################
from Bio.SeqRecord import SeqRecord
def make_protein_record(nucRecord):
    proteinRec = SeqRecord(seq=nucRecord.seq.translate(), id="trans_" + nucRecord.id, description = "translation of CDS, using default table")
    return proteinRec

from Bio import SeqIO
proteins = []
for nucRec in SeqIO.parse("Mouse_genes.fa", "fasta"):
    proteins.append(make_protein_record(nucRec))

SeqIO.write(proteins, "Mouse_genes_translated.fa", "fasta")


# Solutions exercise 3: ###################
# a) count reads
from Bio import SeqIO
count = 0
for rec in SeqIO.parse("Example_800_R1.fastq", "fastq"):
    count += 1
print count, "reads"

# b) filter reads
writer = open('Example_800_R1_goodQual.fastq', 'w')
goodQualCount = 0
for rec in SeqIO.parse("Example_800_R1.fastq", "fastq"):
    if min(rec.letter_annotations["phred_quality"]) >= 10:
        writer.write(rec.format("fastq"))
        goodQualCount += 1
writer.close()
print goodQualCount, "good quality reads (", goodQualCount*100/count, "%)"


# Solutions exercise 4: ###################
# a) 
genetic_code = {
    "GTT": "Val",
    "GCA": "Ala",
    "CCA": "Pro",
    "CAA": "Glu",
    "CCG": "Pro"
}
codon_string = "GTT GCA CCA CAA CCG"
codon_list = codon_string.split()

for codon in codon_list:
    print codon, "codes for", genetic_code[codon]

# b)
def better_mean(values):
    total = 0
    for v in values:
        total += v
    mean = total / float(len(values))
    return mean
print "Mean of values even numbers under 20:", better_mean(range(0, 20, 2))

# c)
def molecular_weight(sequence):
    sequence = sequence.upper()
    base_weights = {'A': 331, 'C': 307, 'G': 347, 'T': 306}
    avg_weight = sum(base_weights.values()) / len(base_weights)
    base_weights['N'] = avg_weight
    total_weight = 0
    for base in sequence:
        total_weight += base_weights[base]
    return total_weight

weight = molecular_weight("AAGGACTGTCNCGTNNCGTAGGATNATAGNN")
print "Weight:", weight, "g/mol"

# d)
gene_file = open("genes.txt", "r")
out_file = open("gene_lengths.txt", "w")

for line in gene_file:
    gene, chrom, start, end = line.split("\t")
    length = int(end) - int(start) + 1
    print >> out_file, gene, length
gene_file.close()
out_file.close()

# e)
import subprocess
output = subprocess.check_output(["ls"], shell=True)
filenames = output.split("\n")
for filename in filenames:
    print filename.upper()

# f.i)
musExp = open("RNAseq_Mus_foldChange.txt", "r") 
for line in musExp:
    lineItems = line.split("\t")
    if lineItems[2] == 'MT':
        print lineItems[1]
musExp.close()

# f.ii) 
musExp = open("RNAseq_Mus_foldChange.txt", "r") 
firstLine = True
for line in musExp:
    if firstLine:
        firstLine = False
    else:
        lineItems = line.split("\t")
        if float(lineItems[6]) < 0.05 and float(lineItems[5]) >= 5 and lineItems[2] == 'Y':
            print line
musExp.close()
